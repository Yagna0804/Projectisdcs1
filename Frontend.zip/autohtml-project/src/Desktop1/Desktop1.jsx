import React, { useState } from "react";
import "./Desktop1.css";

export const Desktop1 = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [showLogin, setShowLogin] = useState(false);

  const toggleMenu = () => {
    setIsOpen((prev) => !prev);
  };

  const toggleLogin = () => {
    setShowLogin((prev) => !prev);
  };

  return (
    <div className="desktop-container">
      {/* Navbar */}
      <nav className="navbar">
        <div className="logo">
          <img src="isdcslogow-1-10.png" alt="ISDCS Logo" />
        </div>
        <div className="menu-toggle" onClick={toggleMenu}>
          ☰
        </div>
        <ul className={`nav-links ${isOpen ? "open" : ""}`}>
          <li><a href="#about">About</a></li>
          <li><a href="#committee">Committee</a></li>
          <li><a href="#dates">Important Dates</a></li>
          <li><a href="#program">Program</a></li>
          <li><button className="login-btn" onClick={toggleLogin}>Login</button></li>
        </ul>
      </nav>

      {/* Login Modal */}
      {showLogin && (
        <div className="login-modal">
          <div className="modal-content">
            <h2>Login</h2>
            <input type="text" placeholder="Username" />
            <input type="password" placeholder="Password" />
            <button className="login-submit">Login</button>
            <button className="close-btn" onClick={toggleLogin}>Close</button>
          </div>
        </div>
      )}
    



      {/* Hero Section */}
      <div id="hero">
        <div className="hero-overlay"></div>
        <div className="hero-content">
          <h1 className="hero-title">ISDCS 2025</h1>
          <p className="hero-subtitle">
            7th International Symposium on Devices, Circuits and Systems <br />
            May 27-30, 2025 | IIEST Shibpur, Kolkata, India
          </p>
          <button className="call-for-papers-btn">Call for Papers</button>
        </div>
      </div>

      {/* Author Registration Section */}
      <div className="author-registration">
        <div className="registration-text">
          <h2>Author Registration Details</h2>
          <p>
            The ISDCS 2025 Program Committee invites original, unpublished paper
            submissions on topics related to Devices, Circuits, and Systems.
            All accepted papers will be published in the Springer Lecture Notes
            in Electrical Engineering (LNEE) series.
          </p>
          <p>
            Each accepted paper must have at least one full paid registration
            by the time the camera-ready manuscript is submitted. Authors are
            required to present their paper at the symposium; otherwise, it
            will not be included in the final proceedings.
          </p>
          <h3>Important Dates:</h3>
          <ul>
            <li>Submission Deadline: March 16, 2025</li>
            <li>Notification of Acceptance: April 20, 2025</li>
            <li>Camera-Ready Manuscript Due: May 4, 2025</li>
          </ul>
        </div>

        {/* Right Side - Image */}
        <div className="registration-image">
          <img src="image-20.png" alt="Author Registration" />
        </div>
      </div>

      {/* Conference Registration Section */}
      <div className="conference-registration-container">
        <div className="conference-registration-pricing">
          Conference Registration Pricing
        </div>

        <div className="conference-registration-details">
          <p>The registration fees for ISDCS 2025 vary based on participant categories and the registration timeline.</p>
          <ol>
            <li>IEEE/IEI Members can register early for $350. If they register after April 30, 2025, the fee increases to $400.</li>
            <li>Non-IEEE/IEI Members need to pay $400 for early registration and $450 if registering late.</li>
            <li>Students who are IEEE/IEI Members are eligible for a discounted rate of $250 before April 30, 2025, and $300 after that.</li>
            <li>Students who are not IEEE/IEI Members must pay $300 for early registration and $350 for late registration.</li>
            <li>Industry Professionals have a registration fee of $500 if they register early, which increases to $550 after April 30, 2025.</li>
            <li>Authors submitting multiple papers must pay an additional fee of $200 per extra paper during early registration, which rises to $250 per paper after the deadline.</li>
            <li>Papers exceeding 15 pages will incur an extra charge of $50 per additional page regardless of the registration period.</li>
          </ol>
          <button className="learn-more-btn">Learn More</button>
        </div>
      </div>

      {/* Sponsorship Section */}
      <section className="sponsorship-section">
        <h2 className="sponsorship-title">Call for Sponsors & Sponsorship Benefits</h2>
        <div className="sponsorship-content">
          <p>Become a Sponsor for ISDCS 2025</p>
          <p>
            The 7th International Symposium on Devices, Circuits, and Systems (ISDCS) 2025
            provides a unique platform for companies, research organizations, and industry leaders
            to showcase their brand, network with experts, and engage with top researchers
            and professionals in the field of electronics, circuits, and system design.
          </p>
          <p>By sponsoring ISDCS 2025, you will have the opportunity to:</p>
          <ul>
            <li>Gain global visibility among researchers, academicians, and industry professionals.</li>
            <li>Showcase your products and services to a highly targeted audience.</li>
            <li>Enhance brand recognition within the scientific and technological community.</li>
            <li>Connect with potential collaborators for research and development.</li>
          </ul>
        </div>
      </section>

      {/* Organizing Committee Section */}
      <section className="committee-section">
        <div className="committee-content">
          <div className="text-container">
            <h2 className="committee-title">Organizing Committee & Advisory Board</h2>
            <p className="committee-description">
              The 7th International Symposium on Devices, Circuits, and Systems (ISDCS 2025) 
              is organized by leading experts and professionals in the field. The organizing committee 
              is responsible for planning, coordinating, and executing all aspects of the conference 
              to ensure a high-quality technical and academic experience for participants.
            </p>
            <button className="submit-button">Submit Your Paper</button>
          </div>
          <div className="image-container">
            <img src="image0.png" alt="Conference" className="committee-image"/>
          </div>
        </div>

        <div className="committee-list">
          <h3>Organizing Committee</h3>
          <ul>
            <li><strong>General Chair:</strong> [Name], [Affiliation]</li>
            <li><strong>Co-Chair(s):</strong> [Name], [Affiliation]</li>
            <li><strong>Conference Secretary:</strong> [Name], [Affiliation]</li>
            <li><strong>Technical Program Chairs:</strong> [Name], [Affiliation]</li>
            <li><strong>Publication Chair:</strong> [Name], [Affiliation]</li>
          </ul>
        </div>
      </section>
      <div className="tpc-container">
        <div className="tpc-content">
          <h1 className="tpc-heading">Technical Program Committee</h1>
          <p className="tpc-description">
            The Technical Program Committee (TPC) is responsible for the review and
            selection of high-quality research papers for presentation at ISDCS 2025.
            This committee consists of researchers, academicians, and industry
            professionals from various domains related to Devices, Circuits, and Systems.
          </p>
        </div>
        <img className="image2" src="image1.png" alt="TPC" />
      </div>

      <footer className="footer">
        <img className="footer-logo" src="isdcslogow-1-10.png" alt="logo" />
        
        <div className="footer-links">
          <a href="#">Home</a>
          <a href="#">About</a>
          <a href="#">Call for Papers</a>
        </div>
      </footer>



    </div>
     
  );
};

export default Desktop1;
